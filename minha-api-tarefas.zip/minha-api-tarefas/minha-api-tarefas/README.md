# 📋 API de Tarefas

Uma API simples para gerenciar tarefas, desenvolvida com Node.js e Express.

## 🚀 Como executar

1. `npm install` - Instalar dependências
2. `npm start` - Executar servidor
3. Acesse: http://localhost:3000

## 📚 Endpoints

- `GET /` - Documentação
- `GET /tarefas` - Listar tarefas
- `POST /tarefas` - Criar tarefa
- `PUT /tarefas/:id` - Atualizar tarefa
- `DELETE /tarefas/:id` - Deletar tarefa
- `POST /login` - Autenticação
- `GET /perfil` - Rota protegida