const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
app.use(express.json());

// Dados iniciais para teste
let tarefas = [
  { id: 1, nome: "Aprender Node.js", concluida: false },
  { id: 2, nome: "Criar API REST", concluida: false },
  { id: 3, nome: "Testar no VS Code", concluida: true }
];

let usuarios = [{ 
  id: 1, 
  username: 'admin', 
  password: bcrypt.hashSync('123456', 8)
}];

// 🏠 ROTA PRINCIPAL - TESTE RÁPIDO
app.get('/', (req, res) => {
  res.json({ 
    mensagem: '🎉 SUA API ESTÁ FUNCIONANDO!',
    status: 'Online',
    data: new Date().toISOString(),
    endpoints: [
      'GET    / → Esta mensagem',
      'GET    /tarefas → Listar todas tarefas',
      'POST   /tarefas → Criar nova tarefa',
      'PUT    /tarefas/:id → Atualizar tarefa',
      'DELETE /tarefas/:id → Deletar tarefa',
      'POST   /login → Fazer login'
    ]
  });
});

// 📋 LISTAR TODAS AS TAREFAS
app.get('/tarefas', (req, res) => {
  res.json({
    sucesso: true,
    total: tarefas.length,
    tarefas: tarefas
  });
});

// ➕ CRIAR NOVA TAREFA
app.post('/tarefas', (req, res) => {
  const { nome } = req.body;
  
  if (!nome || nome.trim() === '') {
    return res.status(400).json({ 
      sucesso: false,
      erro: 'Nome da tarefa é obrigatório' 
    });
  }
  
  const novaTarefa = {
    id: tarefas.length + 1,
    nome: nome.trim(),
    concluida: false,
    criadaEm: new Date().toISOString()
  };
  
  tarefas.push(novaTarefa);
  
  res.status(201).json({
    sucesso: true,
    mensagem: 'Tarefa criada com sucesso!',
    tarefa: novaTarefa
  });
});

// ✏️ ATUALIZAR TAREFA
app.put('/tarefas/:id', (req, res) => {
  const { id } = req.params;
  const { nome, concluida } = req.body;
  
  const tarefa = tarefas.find(t => t.id == id);
  
  if (!tarefa) {
    return res.status(404).json({
      sucesso: false,
      erro: 'Tarefa não encontrada'
    });
  }
  
  if (nome !== undefined) tarefa.nome = nome;
  if (concluida !== undefined) tarefa.concluida = concluida;
  
  tarefa.atualizadaEm = new Date().toISOString();
  
  res.json({
    sucesso: true,
    mensagem: 'Tarefa atualizada!',
    tarefa: tarefa
  });
});

// 🗑️ DELETAR TAREFA
app.delete('/tarefas/:id', (req, res) => {
  const { id } = req.params;
  const index = tarefas.findIndex(t => t.id == id);
  
  if (index === -1) {
    return res.status(404).json({
      sucesso: false,
      erro: 'Tarefa não encontrada'
    });
  }
  
  const tarefaRemovida = tarefas.splice(index, 1)[0];
  
  res.json({
    sucesso: true,
    mensagem: 'Tarefa deletada!',
    tarefa: tarefaRemovida
  });
});

// 🔐 LOGIN
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({
      sucesso: false,
      erro: 'Username e password são obrigatórios'
    });
  }
  
  const usuario = usuarios.find(u => u.username === username);
  
  if (!usuario || !bcrypt.compareSync(password, usuario.password)) {
    return res.status(401).json({
      sucesso: false,
      erro: 'Credenciais inválidas'
    });
  }
  
  const token = jwt.sign(
    { id: usuario.id, username: usuario.username },
    'segredo',
    { expiresIn: '1h' }
  );
  
  res.json({
    sucesso: true,
    mensagem: 'Login realizado!',
    token: token,
    usuario: {
      id: usuario.id,
      username: usuario.username
    }
  });
});

// 🚀 INICIAR SERVIDOR
const PORT = 3000;
app.listen(PORT, () => {
  console.log('✨' + '='.repeat(60));
  console.log('🚀 API DE TAREFAS - INICIADA COM SUCESSO!');
  console.log('✨' + '='.repeat(60));
  console.log(`📍 URL: http://localhost:${PORT}`);
  console.log(`📚 Docs: http://localhost:${PORT}/`);
  console.log('📋 Endpoints disponíveis:');
  console.log(`   GET    http://localhost:${PORT}/`);
  console.log(`   GET    http://localhost:${PORT}/tarefas`);
  console.log(`   POST   http://localhost:${PORT}/tarefas`);
  console.log(`   PUT    http://localhost:${PORT}/tarefas/1`);
  console.log(`   DELETE http://localhost:${PORT}/tarefas/1`);
  console.log(`   POST   http://localhost:${PORT}/login`);
  console.log('✨' + '='.repeat(60));
});